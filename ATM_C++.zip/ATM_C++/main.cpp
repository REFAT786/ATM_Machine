#include <iostream>

using namespace std;

int main()
{

    int option;
    int pin;
    cout<< "welcome to ATM-BOTH"<<endl;
    cout<< "Please enter your pin = ";
    cin>>pin;


    if(pin==3456)
    {

        cout<< "Please enter a option from below"<<endl;
        cout<< "1 Account Statement"<<endl;
        cout<< "2 Withdraw"<<endl;
        cout<< "3 Transfer"<<endl;
        cin>>option;




    int amount,balance,account;
     balance=100000;

    if(option==1)
    {
        cout<<"your account balance = "<<balance<<endl;
    }
    else if(option==2)
    {
        cout<<"Please enter the amount you want to withdraw = ";
        cin>>amount;

        if (amount<=0)
            {
                cout<< "amount can't be zero or negative"<<endl;
            }
            else if (amount>balance)

            {
                cout<< "You don't have enough balance to withdraw"<<endl;
            }
            else
            {
                int available = balance -amount;

                cout << "Your withdraw is successful!"<<endl;
                cout<< "Your available balance is:"<<available<<endl;

            }
    }



    else if(option==3)
    {
        cout<< "your account Balance is:"<<balance<<endl;

        cout<< "Please enter the account number";
        cin>>account;

        if( account>=999999)
            {

                cout<< "Please enter the amount you want to Transfer";
                cin>>amount;


                if (amount<=0)
                {
                    cout<< "amount can't be zero or negative"<<endl;
                }
                else if (amount>balance)
                {
                    cout<< "You don't have enough balance to transfer"<<endl;
                }
                else
                {
                    int available = balance -amount;

                    cout << "Your transfer is successful!"<<endl;
                    cout<< "Your available balance is:"<<available<<endl;
                }
            }

        else
            {
                cout<< "Your account number is invalid" << endl;
            }

    }
    else
        {
            cout<< "invalid option selected"<<endl;

        }

}


    else

        cout<<"your pin number in wrong.\n please try again later"<<endl;


}
